///////////////////////////////////////////////////////////
// �������ƣ��ڰ���
// ���뻷����Visual C++ 2010/6.0��EasyX_2011���ݰ�
// �����д����Ȼ���տ� 1164359890@qq.com
// �����£�2012-2-8
//
////////////////////////////////////////////////////////////
//���زĵ�x1��y1���Ƿ��ģ���Ϊx��ʾ��,���ǻ�����x��ʾ�У�yͬ
////////////////////////////////////////////////////////////


#include <graphics.h>
#include <cstdio>


/*******************************����ȫ�ֱ���*****************************/
char map[8][8];		//����
IMAGE img[6];		//����ͼƬ
int black, white;	//˫����������
char today;			//��ǰ�ֵ�˭��


/**********************************���庯��*****************************/
void load(void)	//����ͼƬ
{
	loadimage(&img[0], "ͼƬ\\�ڿ�.jpg");
	loadimage(&img[1], "ͼƬ\\�׿�.jpg");
	loadimage(&img[2], "ͼƬ\\���Ӻڿ�.jpg");
	loadimage(&img[3], "ͼƬ\\���Ӱ׿�.jpg");
	loadimage(&img[4], "ͼƬ\\���Ӻڿ�.jpg");
	loadimage(&img[5], "ͼƬ\\���Ӱ׿�.jpg");
}

void print(void)	//������
{
	int x, y;
	black = white = 0;
	for(x = 0; x < 8; x++)
		for(y = 0; y < 8; y++)
			switch(map[x][y])
			{
				case 0:
					if((x + y) % 2)
						putimage(60 * y, 60 * x, &img[0]);
					else
						putimage(60 * y, 60 * x, &img[1]);
					break;
				case 'B':
					if((x + y) % 2)
						putimage(60 * y, 60 * x, &img[2]);
					else
						putimage(60 * y, 60 * x, &img[3]);
					black++;
					break;
				case 'W':
					if((x + y) % 2)
						putimage(60 * y, 60 * x, &img[4]);
					else
						putimage(60 * y, 60 * x, &img[5]);
					white++;
					break;
			}
}

inline void print1(void)	//����ǰ˭�ߵ�
{
	setcolor(WHITE);
	bar(530, 60, 590, 120);
	bar(530, 360, 590, 420);
	if(today == 'B')
		putimage(530, 60, &img[3]);
	else
		putimage(530, 360, &img[4]);
}

void draw(int x, int y, char a)	//�µ�ǰ��
{
	char b = ((a == 'B') ? 'W' : 'B');	//�з���
	int x1, y1, x2, y2;
	bool sign = false;					//�Ƿ�Խ���з���
	for(x1 = x - 1; x1 >= 0 && map[x1][y]; x1--)	//�ж��Ϸ�
	{
		if(map[x1][y] == b)
			sign = true;
		else
		{
			if(sign)
			{
				for(x2 = x - 1; x2 > x1; x2--)		//�ж��·�
					map[x2][y] = a;
			}
			break;
		}
	}
	sign = false;
	for(x1 = x + 1; x1 < 8 && map[x1][y]; x1++) 	//�ж��ҷ�
	{
		if(map[x1][y] == b)
			sign = true;
		else
		{
			if(sign)
			{
				for(x2 = x + 1; x2 < x1; x2++)
					map[x2][y] = a;
			}
			break;
		}
	}
	sign = false;
	for(y1 = y - 1; y1 >= 0 && map[x][y1]; y1--)	//�ж���
	{
		if(map[x][y1] == b)
			sign = true;
		else
		{
			if(sign)
			{
				for(y2 = y - 1; y2 > y1; y2--)
					map[x][y2] = a;
			}
			break;
		}
	}
	sign = false;
	for(y1 = y + 1; y1 < 8 && map[x][y1]; y1++) 	//�ж��ҷ�
	{
		if(map[x][y1] == b)
			sign = true;
		else
		{
			if(sign)
			{
				for(y2 = y + 1; y2 < y1; y2++)
					map[x][y2] = a;
			}
			break;
		}
	}
	sign = false;
	for(x1 = x - 1, y1 = y - 1; x1 >= 0 && y1 >= 0 && map[x1][y1]; x1--, y1--)	//���Ϸ�
	{
		if(map[x1][y1] == b)
			sign = true;
		else
		{
			if(sign)
			{
				for(x2 = x - 1, y2 = y - 1; x2 > x1 && y2 > y1; x2--, y2--)
					map[x2][y2] = a;
			}
			break;
		}
	}
	sign = false;
	for(x1 = x + 1, y1 = y + 1; x1 < 8 && y1 < 8 && map[x1][y1]; x1++, y1++)	//���·�
	{
		if(map[x1][y1] == b)
			sign = true;
		else
		{
			if(sign)
			{
				for(x2 = x + 1, y2 = y + 1; x2 < x1 && y2 < y1; x2++, y2++)
					map[x2][y2] = a;
			}
			break;
		}
	}
	sign = false;
	for(x1 = x + 1, y1 = y - 1; x1 < 8 && y1 >= 0 && map[x1][y1]; x1++, y1--)	//���·�
	{
		if(map[x1][y1] == b)
			sign = true;
		else
		{
			if(sign)
			{
				for(x2 = x + 1, y2 = y - 1; x2 < x1 && y2 > y1; x2++, y2--)
					map[x2][y2] = a;
			}
			break;
		}
	}
	sign = false;
	for(x1 = x - 1, y1 = y + 1; x1 >= 0 && y1 < 8 && map[x1][y1]; x1--, y1++)	//���Ϸ�
	{
		if(map[x1][y1] == b)
			sign = true;
		else
		{
			if(sign)
			{
				for(x2 = x - 1, y2 = y + 1; x2 > x1 && y2 < y1; x2--, y2++)
					map[x2][y2] = a;
			}
			break;
		}
	}
	map[x][y] = a;
	print();
}

bool judge(int x, int y, char a)	//�жϵ�ǰ�Ƿ�������£�ͬdraw����
{
	char b = ((a == 'B') ? 'W' : 'B');
	int x1, y1;
	bool sign = false, sign1 = false;	//sign1�ж��Ƿ���Ч
	if(map[x][y])	//�����ǰ���ǿյķ��ؼ�ֵ
		return false;
	for(x1 = x - 1; x1 >= 0 && map[x1][y]; x1--) 
	{
		if(map[x1][y] == b)
			sign = true;
		else
		{
			if(sign)
				sign1 = true;
			break;
		}
	}
	sign = false;
	for(x1 = x + 1; x1 < 8 && map[x1][y]; x1++) 
	{
		if(map[x1][y] == b)
			sign = true;
		else
		{
			if(sign)
				sign1 = true;
			break;
		}
	}
	sign = false;
	for(y1 = y - 1; y1 >= 0 && map[x][y1]; y1--) 
	{
		if(map[x][y1] == b)
			sign = true;
		else
		{
			if(sign)
				sign1 = true;
			break;
		}
	}
	sign = false;
	for(y1 = y + 1; y1 < 8 && map[x][y1]; y1++) 
	{
		if(map[x][y1] == b)
			sign = true;
		else
		{
			if(sign)
				sign1 = true;
			break;
		}
	}
	sign = false;
	for(x1 = x - 1, y1 = y - 1; x1 >= 0 && y1 >= 0 && map[x1][y1]; x1--, y1--) 
	{
		if(map[x1][y1] == b)
			sign = true;
		else
		{
			if(sign)
				sign1 = true;
			break;
		}
	}
	sign = false;
	for(x1 = x + 1, y1 = y + 1; x1 < 8 && y1 < 8 && map[x1][y1]; x1++, y1++) 
	{
		if(map[x1][y1] == b)
			sign = true;
		else
		{
			if(sign)
				sign1 = true;
			break;
		}
	}
	sign = false;
	for(x1 = x + 1, y1 = y - 1; x1 < 8 && y1 >= 0 && map[x1][y1]; x1++, y1--) 
	{
		if(map[x1][y1] == b)
			sign = true;
		else
		{
			if(sign)
				sign1 = true;
			break;
		}
	}
	sign = false;
	for(x1 = x - 1, y1 = y + 1; x1 >= 0 && y1 < 8 && map[x1][y1]; x1--, y1++) 
	{
		if(map[x1][y1] == b)
			sign = true;
		else
		{
			if(sign)
				sign1 = true;
			break;
		}
	}
	return sign1;
}

bool win(void)	//�ж��Ƿ��������
{
	int x, y;
	for(x = 0; x < 8; x++)
		for(y = 0; y < 8; y++)
			if(judge(x, y, today))
				return true;
	return false;
}

bool quit(void)	//�ж��Ƿ�����
{
	int x, y;
	bool b = false, w = false;
	for(x = 0; x < 8; x++)
		for(y = 0; y < 8; y++)
		{
			if(map[x][y] == 'B')
				b = true;
			else if(map[x][y] == 'W')
				w = true;
		}
	return(b && w);
}

bool ask(void)	//�����Ի���
{
	HWND wnd = GetHWnd();
	int key;
	char str[30] = "�ڣ�", s[2];
	sprintf(s, "%d", black);
	strcat(str, s);
	strcat(str, " �ף�");
	sprintf(s, "%d", white);
	strcat(str, s);
	strcat(str, "\n�Ƿ����¿�ʼ��");
	if(black == white)
		key = MessageBox(wnd, str, "�;�", MB_YESNO | MB_ICONQUESTION);
	else if(black > white)
		key = MessageBox(wnd, str, "��ʤ", MB_YESNO | MB_ICONQUESTION);
	else
		key = MessageBox(wnd, str, "��ʤ", MB_YESNO | MB_ICONQUESTION);
	if(key == IDYES)
		return true;
	else
		return false;
}

void play(void)	//��Ϸ����
{
	MOUSEMSG m;
	int x, y;
	for(x = 0; x < 8; x++)
		for(y = 0; y < 8; y++)
			map[x][y] = 0;
	map[3][4] = map[4][3] = 'B';
	map[3][3] = map[4][4] = 'W';
	today = 'B';
	print();
	print1();
	do
	{
		do
		{
			while(true)
			{
				m = GetMouseMsg();				//��ȡ�����Ϣ
				if(m.uMsg == WM_LBUTTONDOWN)	//���������
					break;
			}
			x = m.y / 60;
			y = m.x / 60;
			if(judge(x, y, today))	//�����ǰλ����Ч
			{
				draw(x, y, today);	//����
				today = ((today == 'B') ? 'W' : 'B');
				print1();			//����
			}
		}while(win() && quit());	//�����ǰ�������
		today = ((today == 'B') ? 'W' : 'B');
		print1();
	}while(win() && quit());	//˫���ж�
}

int main(void)	//������
{
	initgraph(640, 480);
	load();
	setbkcolor(WHITE);
	cleardevice();
	do
	{
		play();
	}while(ask());
	closegraph();
	return 0;
}

/***********************************THE END************************************/